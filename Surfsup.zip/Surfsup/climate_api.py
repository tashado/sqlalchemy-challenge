# Import dependencies
import numpy as np
import pandas as pd
import datetime as dt
from numpy import mean
import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func
import scipy

# Import Flask
from flask import Flask, jsonify
import json

# Create engine using the `hawaii.sqlite` database file
engine = create_engine("sqlite:///Resources/hawaii.sqlite")

# Declare a Base using `automap_base()`
base = automap_base()

# Use the Base class to reflect the database tables
base.prepare(autoload_with=engine)

# Assign the measurement class to a variable called `Measurement` and
# assign the station class to a variable called `Station`
measurement = base.classes.measurement
station = base.classes.station

# Create an app
app = Flask(__name__)

# Define routes
@app.route("/")
def home():
    print("Server received requet for Home page...")

    # Return all possible routes
    return(
        f"Welcome to my Home page!<br/>"
        f"Available Routes:<br/>"
        f"/api/v1.0/precipitation<br/>"
        f"/api/v1.0/stations<br/>"
        f"/api/v1.0/tobs<br/>"
        f"/api/v1.0/start_date= <br/>"
        f"/api/v1.0/start_date=/end_date="
    )

@app.route("/api/v1.0/precipitation")
def precipitation():

    # Create engine
    session = Session(engine)

    # Year previous date from latest data
    year_ago = dt.date(2017,8,23) - dt.timedelta(days=366)

    # Query measurement date and precipitation data within the last year
    prcp_query = session.query(measurement.date, measurement.prcp).\
        filter(measurement.date > year_ago).all()
    session.close()

    prcp_query_list = list(np.ravel(prcp_query))

    # Return json file
    return jsonify(prcp_query_list)

@app.route("/api/v1.0/stations")
def stations():
    
    # Create engine
    session = Session(engine)

    # Query for all stations names
    active_query = session.query(station.station).all()
    session.close()
    
    # Convert list to json-formatted string
    active_query_list = list(np.ravel(active_query))

    # Return json file
    return jsonify(active_query_list)

@app.route("/api/v1.0/tobs")
def tobs():
    
    # Create engine
    session = Session(engine)

    # Year previous date from latest data
    year_ago = dt.date(2017,8,23) - dt.timedelta(days=366)

    # Query for most active station
    active_query = session.query(measurement.station, func.count(measurement.prcp)).group_by(measurement.station).all()
    active_query = sorted(active_query, key=lambda x: x[1], reverse=True)
    active_station = active_query[0][0]

    # Query for the most active station's temperatures from within the last year
    station_query = session.query(measurement.date, measurement.tobs).\
        filter(measurement.station == active_station).\
        filter(measurement.date > year_ago).all()
    session.close()
    
    # Convert list to json-formatted string
    station_query_list = list(np.ravel(station_query))

    # Return json file
    return jsonify(station_query_list)

@app.route("/api/v1.0/start_date=<startDate>")
def start(startDate):
    # Create engine
    session = Session(engine)

    startDate_query = session.query(measurement.prcp).\
        filter(measurement.date >= startDate).\
        filter(measurement.prcp != "none").all()
    session.close()

    # Convert list to json-formatted string
    startDate_list = list(np.ravel(startDate_query))

    data = [{"max": max(startDate_list), "min": min(startDate_list), "mean": mean(startDate_list)}]

    # Return json file
    return jsonify(data)


@app.route("/api/v1.0/start_date=<startDate>/end_date=<endDate>")
def startEnd(startDate, endDate):
    # Create engine
    session = Session(engine)

    start_end_query = session.query(measurement.prcp).\
        filter(measurement.date >= startDate).\
        filter(measurement.date <= endDate).\
        filter(measurement.prcp != "none").all()
    session.close()

    # Convert list to json-formatted string
    startEndDate_list = list(np.ravel(start_end_query))

    data = [{"max": max(startEndDate_list), "min": min(startEndDate_list), "mean": mean(startEndDate_list)}]

    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)